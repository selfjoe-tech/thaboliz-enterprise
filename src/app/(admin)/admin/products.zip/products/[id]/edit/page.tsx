import ProductForm from "@/components/admin/(dashboard)/catalogue/products/product-form";
import {
  getCatalogueProductById,
  listCatalogueCategoryOptions,
} from "@/lib/actions/dashboard-info/catalogue-product";

export default async function EditCatalogueProductPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const resolved = await params;

  const id = resolved?.id;

  if (!id || id === "undefined" || id === "null") {
    throw new Error(`Invalid route param id: ${String(id)}`);
  }

  const [product, categories] = await Promise.all([
    getCatalogueProductById(id),
    listCatalogueCategoryOptions(),
  ]);

  return (
    <div className="p-4 md:p-6">
      <h1 className="mb-6 text-2xl font-semibold">Edit Product</h1>
      <ProductForm mode="edit" categories={categories} product={product} />
    </div>
  );
}