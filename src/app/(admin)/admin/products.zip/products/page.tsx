import ProductListPage from "@/components/admin/(dashboard)/products/product-list";
import {
  listCatalogueProductsPaged,
  listCatalogueCategoryOptions,
} from "@/app/lib/actions/dashboard-info/catalogue-product";

type Props = {
  searchParams?: any;
};

export default async function CatalogueProductsPage({ searchParams }: Props) {
  const sp =
    searchParams && typeof searchParams.then === "function"
      ? await searchParams
      : searchParams ?? {};

  const page = Math.max(1, Number(sp?.page ?? 1));
  const pageSize = Math.max(1, Number(sp?.pageSize ?? 10));
  const search = typeof sp?.search === "string" ? sp.search : "";
  const categoryId = typeof sp?.category === "string" ? sp.category : "all";
  const retailer = typeof sp?.retailer === "string" ? sp.retailer : "all";

  const [{ items, total }, categories] = await Promise.all([
    listCatalogueProductsPaged(page, pageSize, search, categoryId, retailer),
    listCatalogueCategoryOptions(),
  ]);

  return (
    <ProductListPage
      initialItems={items}
      total={total}
      initialPage={page}
      initialPageSize={pageSize}
      categories={categories}
      initialSearch={search}
      initialCategory={categoryId}
      initialRetailer={retailer}
    />
  );
}