// app/lib/actions/dashboard-info/product.ts
import { supabase } from "@/app/lib/supabaseClient"; // adjust if your client path is different
import { Product, Category } from "@/app/definitions/product";

/**
 * Server-side paged fetch for products.
 * page: 1-based
 * pageSize: number of rows per page
 */
export async function listProductsPaged(page = 1, pageSize = 10) {
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  const { data, error, count } = await supabase
    .schema("public")
    .from("products")
    .select("*", { count: "exact" })
    .order("created_at", { ascending: false })
    .range(from, to);

  if (error) {
    console.error("listProductsPaged error:", error);
    throw error;
  }

  return {
    items: (data ?? []) as Product[],
    total: typeof count === "number" ? count : data?.length ?? 0,
  };
}

/**
 * Fetch categories
 */
export async function listCategories(): Promise<Category[]> {
  const { data, error } = await supabase
    .schema("public")
    .from("categories")
    .select("*")
    .order("name", { ascending: true });

  if (error) {
    console.error("listCategories error:", error);
    throw error;
  }
  return data ?? [];
}

/**
 * Toggle publish/unpublish status (string status "published" / "unpublished")
 */
export async function togglePublishStatus(id: string, publish: boolean) {
  const newStatus = publish ? "published" : "unpublished";
  const { data, error } = await supabase
    .schema("public")
    .from("products")
    .update({ status: newStatus })
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

/**
 * Delete product row by id
 */
export async function deleteProductAction(id: string) {
  const { data, error } = await supabase
    .from("products")
    .delete()
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data;
}


export async function createProductAction(payload: any) {
  const res = await fetch("/api/products/create", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return res.json();
}

export async function getProductById(id: string): Promise<Product | null> {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .eq("id", id)
    .single();

  if (error) {
    console.error("getProductById error:", error);
    throw error;
  }
  return data ?? null;
}


export async function updateProductAction(payload: any) {
  const res = await fetch("/api/products/update", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return res.json();
}


/**
 * Try to find product by slug first (common for SEO-friendly urls),
 * otherwise fallback to name (case-insensitive, dashes => spaces).
 *
 * Returns `null` when not found.
 */
export async function getProductByName(productNameOrSlug: string) {
  if (!productNameOrSlug) return null;

  // prefer slug column if you have one
  // (e.g. product row contains `slug` like "organic-mangoes")
  const slug = productNameOrSlug.trim();

  // Try slug exact match first
  

  // fallback: search by name (convert dashes to spaces, case-insensitive)
  const nameCandidate = slug.replace(/-/g, " ");

  const { data, error } = await supabase
    .from("products")
    .select("*")
    .ilike("name", nameCandidate)
    .maybeSingle();

  if (error) {
    console.error("getProductByName name lookup error:", error);
    return null;
  }

  if (!data) return null;

  return normalizeProductRow(data);
}

/**
 * Normalize DB row to shape the UI expects.
 * Adjust fields mapping depending on your table columns.
 */
function normalizeProductRow(row: any) {
  // If your product stores image URLs in `image_url` (single) and a JSON array in `images`,
  // adapt accordingly — this is defensive merging.
  const images: string[] =
    Array.isArray(row.images) && row.images.length
      ? row.images
      : row.image_url
      ? [row.image_url]
      : row.image
      ? Array.isArray(row.image)
        ? row.image
        : [row.image]
      : [];

  return {
    id: row.id,
    name: row.name ?? row.title ?? "",
    title: row.title ?? row.name ?? "",
    description: row.description ?? row.long_description ?? "",
    price: typeof row.price === "number" ? row.price : Number(row.price ?? 0),
    oldPrice:
      typeof row.old_price === "number" ? row.old_price : row.old_price ? Number(row.old_price) : null,
    discount: row.discount ?? null,
    sku: row.sku ?? row.id ?? "N/A",
    images,
    image: images[0] ?? null,
    vendor: row.vendor ?? null,
    rating: typeof row.rating === "number" ? row.rating : Number(row.rating ?? 0),
    reviews: typeof row.reviews === "number" ? row.reviews : Number(row.reviews ?? 0),
    categories: row.categories ?? (row.category ? [row.category] : []),
    soldText: row.sold_text ?? "",
    // include raw row so consumers can access other fields if needed:
    _raw: row,
  } ;
}
