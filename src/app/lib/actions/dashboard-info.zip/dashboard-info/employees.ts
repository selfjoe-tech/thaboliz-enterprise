// server-side helpers for employees pages
import { supabaseAdmin } from "@/app/lib/supabaseAdmin"; // adjust to your project

export async function listEmployeesPaged(page = 1, pageSize = 10, search?: string) {
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabaseAdmin
    .schema("admin_auth")
    .from("auth")
    .select("id, created_at, name, email, role", { count: "exact" })
    .order("created_at", { ascending: false });

  if (search && search.trim()) {
    query = query.ilike("name", `%${search.trim()}%`);
  }

  const { data, error, count } = await query.range(from, to);
  if (error) {
    console.error("listEmployeesPaged error:", error);
    throw error;
  }

  return { items: data ?? [], total: typeof count === "number" ? count : 0 };
}

// server-side
export async function getEmployeeWithOrdersPaged(
  userId: string,
  page = 1,
  pageSize = 10,
  search?: string
) {
  const { data: employee, error: empErr } = await supabaseAdmin
    .schema("admin_auth")
    .from("auth")
    .select("id, created_at, name, email, role")
    .eq("id", userId)
    .single();

  if (empErr) {
    console.error("getEmployeeWithOrdersPaged - empErr:", empErr);
    throw empErr;
  }

  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let ordersQuery = supabaseAdmin
    .from("orders")
    .select("id, order_number, status, total, created_at", { count: "exact" })
    .or(`marked_shipped_id.eq.${userId},canceled_id.eq.${userId}`)
    .order("created_at", { ascending: false });

  if (search && String(search).trim().length) {
    const q = String(search).trim();

    // If it's only digits, treat as exact numeric id lookup (safe for bigint)
    if (/^\d+$/.test(q)) {
      // exact id match OR you can also match order_number if you want both:
      ordersQuery = ordersQuery.or(`id.eq.${q},order_number.ilike.%${q}%`);
    } else {
      // non-numeric search — do not call ilike on id (bigint) => we fallback to searching order_number
      ordersQuery = ordersQuery.ilike("order_number", `%${q}%`);
    }
  }

  const { data: orders, error: ordersErr, count } = await ordersQuery.range(from, to);
  if (ordersErr) {
    console.error("getEmployeeWithOrdersPaged - ordersErr:", ordersErr);
    throw ordersErr;
  }

  return {
    employee,
    orders: orders ?? [],
    totalOrdersCount: typeof count === "number" ? count : 0,
  };
}


// toggle access by flipping role between 'revoked' and 'user' (adjust if you have different role values)
// app/lib/actions/dashboard-info/employees.ts (or wherever your server actions live)
export async function toggleAccess(userId: string) {
  // find the latest session for this user (by created_at desc)
  const { data: latestSession, error: sessErr } = await supabaseAdmin
    .schema("admin_auth")
    .from("sessions")
    .select("id, revoked, created_at")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle(); // maybeSingle avoids throwing if no rows

  if (sessErr) {
    console.error("toggleAccess - sessErr:", sessErr);
    throw sessErr;
  }

  if (!latestSession) {
    // no sessions found for this user
    const msg = "No session found for user";
    console.warn("toggleAccess -", msg, userId);
    throw new Error(msg);
  }

  const currentRevoked = Boolean(latestSession.revoked);
  const newRevoked = !currentRevoked;

  // update only that session row (by session id)
  const { data: updated, error: updErr } = await supabaseAdmin
    .schema("admin_auth")
    .from("sessions")
    .update({ revoked: newRevoked })
    .eq("id", latestSession.id)
    .select()
    .maybeSingle();

  if (updErr) {
    console.error("toggleAccess - updErr:", updErr);
    throw updErr;
  }

  return {
    action: newRevoked ? "revoked" : "granted",
    sessionId: latestSession.id,
    updatedSession: updated ?? null,
  };
}



export async function deleteEmployee(id: string) {
  const { error } = await supabaseAdmin
    .schema("admin_auth")
    .from("auth")
    .delete()
    .eq("id", id);
  if (error) {
    console.error("deleteEmployee error:", error);
    throw error;
  }
  return { ok: true };
}

// app/lib/actions/dashboard-info/employees.ts (append these exports)

export async function createEmployee({ name, email, role }: { name: string; email: string; role: string }) {
  const { data, error } = await supabaseAdmin
    .schema("admin_auth")
    .from("auth")
    .insert([{ name, email, role }])
    .select("id, created_at, name, email, role")
    .single();

  if (error) {
    console.error("createEmployee - error:", error);
    throw error;
  }

  return data;
}

export async function updateEmployee({ id, name, email, role }: { id: string; name?: string; email?: string; role?: string }) {
  const { data, error } = await supabaseAdmin
    .schema("admin_auth")
    .from("auth")
    .update({ name, email, role })
    .eq("id", id)
    .select("id, created_at, name, email, role")
    .single();

  if (error) {
    console.error("updateEmployee - error:", error);
    throw error;
  }

  return data;
}
