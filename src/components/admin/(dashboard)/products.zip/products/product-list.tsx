// app/components/admin/(dashboard)/products/product-list.tsx
"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { deleteProductAction, togglePublishStatus } from "@/app/lib/actions/dashboard-info/product";
import ConfirmModal from "@/components/ui/confirm-modal";
import Pagination from "@/components/ui/pagination";
import ProductCard from "./product-card";
import TableRow from "./table-row";

type Product = {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  image_url: string;
  status: string;
};

interface CategoryOption {
  label: string;
  value: string;
}

export default function ProductListPage({
  cats,
  initialItems,
  total,
  initialPage = 1,
  initialPageSize = 10,
}: {
  cats: CategoryOption[];
  initialItems: Product[];
  total: number;
  initialPage?: number;
  initialPageSize?: number;
}) {
  const router = useRouter();

  // server-provided items for the current page
  const [items, setItems] = useState<Product[]>(initialItems);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  // publish modal request state:
  const [publishRequest, setPublishRequest] = useState<{
    id: string;
    publish: boolean;
    open: boolean;
  } | null>(null);
  const [publishingId, setPublishingId] = useState<string | null>(null);

  // pagination state that reflects URL params (server provided initial)
  const [currentPage, setCurrentPage] = useState<number>(initialPage);
  const [pageSize, setPageSize] = useState<number>(initialPageSize);

  // when server rehydrates with new props, sync
  useEffect(() => {
    setItems(initialItems);
  }, [initialItems]);

  useEffect(() => {
    setCurrentPage(initialPage);
  }, [initialPage]);

  useEffect(() => {
    setPageSize(initialPageSize);
  }, [initialPageSize]);

  // Client-side filtering applied to the current page set only
  const filtered = useMemo(() => {
    return items.filter(
      (p) =>
        (category === "All" || p.category === category) &&
        p.name.toLowerCase().includes(search.toLowerCase())
    );
  }, [items, search, category]);

  // total pages are computed from server 'total'
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  // Confirm publish/unpublish request (open modal)
  const handleRequestTogglePublish = (id: string, publish: boolean) => {
    setPublishRequest({ id, publish, open: true });
  };

  // Confirmed publish/unpublish -> optimistic update then call server; revert if fails
  const handleConfirmPublish = async () => {
    if (!publishRequest) return;
    const { id, publish } = publishRequest;

    // snapshot to revert on error
    const prevItems = items.slice();

    // optimistic update: update local items if item exists in current page
    setItems((prev) => prev.map((p) => (p.id === id ? { ...p, status: publish ? "published" : "unpublished" } : p)));

    setPublishRequest(null);
    setPublishingId(id);

    try {
      await togglePublishStatus(id, publish);
      // success: server is source of truth; we keep optimistic state
    } catch (err) {
      console.error("toggle publish failed", err);
      setItems(prevItems);
      alert("Failed to update status.");
    } finally {
      setPublishingId(null);
    }
  };

  // Delete: optimistic remove from local items, call server, revert on error
  const handleDelete = async (id: string) => {
    const prevItems = items.slice();
    setItems((prev) => prev.filter((p) => p.id !== id));
    setDeleteId(null);

    try {
      await deleteProductAction(id);
      // success; note server's total decreased — you may want to navigate or refresh list
    } catch (err) {
      console.error("delete failed", err);
      setItems(prevItems);
      alert("Failed to delete product.");
    }
  };

  // navigate to a different page by updating the URL search params
  const gotoPage = (page: number, size = pageSize) => {
    const url = new URL(window.location.href);
    url.searchParams.set("page", String(page));
    url.searchParams.set("pageSize", String(size));
    // preserve other params if any (e.g., other filters you might add)
    router.push(url.pathname + url.search);
    // we don't set items here — server will rerender component with new initialItems
  };

  // page size change handler
  const handlePageSizeChange = (newSize: number) => {
    const url = new URL(window.location.href);
    url.searchParams.set("page", "1"); // reset to 1 when changing size
    url.searchParams.set("pageSize", String(newSize));
    router.push(url.pathname + url.search);
  };

  console.log(cats, "<________ cats")

  return (
    <div className="p-0 md:p-4">
      <h1 className="text-xl md:text-2xl font-bold mb-6">Products</h1>

      {/* Controls */}
      <div className="flex flex-col md:flex-row gap-3 mb-6">
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border border-gray-300 px-3 py-2 rounded-lg w-full md:w-1/3 focus:outline-none focus:ring-2 focus:ring-black"
        />

        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="border border-gray-300 px-3 py-2 rounded-lg w-full md:w-1/4 focus:outline-none focus:ring-2 focus:ring-black"
        >
          <option value="All">All Categories</option>
          {cats?.map((cat) => (
            <option key={cat.value} value={cat.label}>
              {cat.label}
            </option>
          ))}
        </select>

        <select
          value={pageSize}
          onChange={(e) => handlePageSizeChange(Number(e.target.value))}
          className="border border-gray-300 px-3 py-2 rounded-lg w-full md:w-40 focus:outline-none focus:ring-2 focus:ring-black"
        >
          <option value={5}>5 / page</option>
          <option value={10}>10 / page</option>
          <option value={20}>20 / page</option>
        </select>

        <Link
          href="/admin/products/batch"
          className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition text-center"
        >
          + Add Products
        </Link>
      </div>

      {/* Mobile pagination */}
      <div className="md:hidden mb-4">
        <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={(p) => gotoPage(p)} />
      </div>

      {/* Mobile list */}
      <div className="space-y-4 md:hidden">
        {filtered.map((product) => (
          <ProductCard key={product.id} product={product} setDeleteId={setDeleteId} setImageUrl={setImageUrl} />
        ))}
      </div>

      {/* Desktop table */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full border border-gray-200 shadow-sm rounded-lg overflow-hidden">
          <thead className="bg-gray-50 text-sm">
            <tr>
              <th className="px-4 py-3 text-left">Image</th>
              <th className="px-4 py-3 text-left">Name</th>
              <th className="px-4 py-3 text-left">Category</th>
              <th className="px-4 py-3 text-left">Price</th>
              <th className="px-4 py-3 text-left"></th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-left">Actions</th>
            </tr>
          </thead>
          <tbody className="text-sm divide-y divide-gray-200">
            {filtered.map((product) => (
              <TableRow
                key={product.id}
                product={product}
                setDeleteId={setDeleteId}
                setImageUrl={setImageUrl}
                onRequestTogglePublish={handleRequestTogglePublish}
                publishingId={publishingId}
              />
            ))}
          </tbody>
        </table>
      </div>

      {/* Desktop pagination */}
      <div className="mt-4 flex items-center justify-end">
        <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={(p) => gotoPage(p)} />
      </div>

      {/* Delete modal */}
      {deleteId && (
        <ConfirmModal
          open={!!deleteId}
          title="Delete product?"
          description="This will permanently delete the product."
          confirmLabel="Delete"
          confirmIntent="danger"
          isProcessing={false}
          onClose={() => setDeleteId(null)}
          onConfirm={async () => {
            if (deleteId) await handleDelete(deleteId);
          }}
        />
      )}

      {/* Publish/Unpublish modal */}
      {publishRequest && (
        <ConfirmModal
          open={publishRequest.open}
          title={publishRequest.publish ? "Publish product?" : "Unpublish product?"}
          description={
            publishRequest.publish
              ? "Make this product visible for customers?"
              : "Hide this product from customers? You can publish it again anytime."
          }
          confirmLabel={publishRequest.publish ? "Publish" : "Unpublish"}
          confirmIntent={publishRequest.publish ? "primary" : "danger"}
          isProcessing={!!publishingId}
          onClose={() => setPublishRequest(null)}
          onConfirm={handleConfirmPublish}
        />
      )}
    </div>
  );
}
