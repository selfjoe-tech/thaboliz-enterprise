// components/(dashboard)/products/table-row.tsx
"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";


type Product = {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  image_url: string;
  isPublished: boolean;
  status: string;
}

type Props = {
  product: Product;
  setDeleteId: (id: string | null) => void;
  setImageUrl: (url: string | null) => void;
  onRequestTogglePublish: (id: string, publish: boolean) => void; // parent will handle confirm modal + optimistic update
  publishingId?: string | null; // id currently being processed for publish/unpublish
};

const TableRow = ({
  product,
  setDeleteId,
  setImageUrl,
  onRequestTogglePublish,
  publishingId,
}: Props) => {
  const [imageLoaded, setImageLoaded] = useState(false);

  const currentlyPublished = product.status === "published";
  const isPublishing = publishingId === product.id;
  console.log(product.status, "<==== status column")

  return (
    <tr key={product.id} className="hover:bg-gray-50 transition-colors">
      <td className="px-4 py-3">
        <div className="relative w-12 h-12">
          {!imageLoaded && (
            <div className="absolute inset-0 bg-gray-200 animate-pulse rounded-md border border-gray-200" />
          )}
          <Image
            src={product.image_url}
            alt={product.name}
            fill
            className={`object-cover rounded-md border border-gray-200 transition-opacity duration-300 ${
              imageLoaded ? "opacity-100" : "opacity-0"
            }`}
            onLoad={() => setImageLoaded(true)}
          />
        </div>
      </td>

      <td className="px-4 py-3 font-medium">{product.name}</td>
      <td className="px-4 py-3">{product.category}</td>
      <td className="px-4 py-3">R{product.price.toFixed(2)}</td>
      <td className="px-4 py-3">{product.stock}</td>
      <td className="px-4 py-3">
        <span
          className={`px-2 py-0.5 text-xs rounded-full ${
            product.status === "published" ? "bg-green-100 text-green-700" : "bg-gray-200 text-gray-600"
          }`}
        >
          {product.status === "published" ? "Published" : "Unpublished"}
        </span>
      </td>

      <td className="py-3">
        <div className="inline-flex gap-2 items-center">
          <Link
            href={`/admin/products/${product.id}/edit`}
            className="px-3 py-1 rounded-md border border-gray-300 text-xs hover:bg-gray-100"
          >
            Edit
          </Link>

          <button
            onClick={() => {
              setDeleteId(product.id);
              setImageUrl(product.image_url);
            }}
            className="px-3 py-1 rounded-md border border-red-300 text-xs text-red-600 hover:bg-red-50"
          >
            Delete
          </button>

          <button
            onClick={() => onRequestTogglePublish(product.id, !currentlyPublished)}
            disabled={isPublishing}
            className={`px-3 py-1 rounded-md text-xs border ${
              currentlyPublished
                ? "border-yellow-600 text-yellow-700 hover:bg-yellow-50"
                : "border-sky-600 text-sky-700 hover:bg-sky-50"
            } ${isPublishing ? "opacity-60 cursor-not-allowed" : ""}`}
          >
            {isPublishing ? "Processing..." : currentlyPublished ? "Unpublish" : "Publish"}
          </button>
        </div>
      </td>
    </tr>
  );
};

export default TableRow;
