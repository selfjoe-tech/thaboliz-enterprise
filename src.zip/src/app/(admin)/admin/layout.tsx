import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import AdminSidebar from "@/components/admin/AdminSidebar";

type AdminLink = {
  href: string;
  label: string;
  required: string[];
};

const ALL_LINKS: AdminLink[] = [
  { href: "/admin", label: "Dashboard", required: ["view_dashboard"] },
  { href: "/admin/products", label: "Products", required: ["view_products", "manage_products"] },
  { href: "/admin/categories", label: "Categories", required: ["view_categories", "manage_categories"] },
  { href: "/admin/orders", label: "Orders", required: ["view_orders", "manage_orders"] },
  { href: "/admin/users", label: "Users", required: ["view_users", "manage_users"] },
];

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    redirect("/admin-login?callbackUrl=/admin");
  }

  const permissions = session.user.permissions ?? [];

  if (!permissions.includes("access_admin")) {
    redirect("/");
  }

  const visibleLinks = ALL_LINKS
    .filter((link) =>
      link.required.some((permission) => permissions.includes(permission))
    )
    .map((link) => ({
      href: link.href,
      label: link.label,
    }));

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <div className="grid min-h-screen md:grid-cols-[260px_1fr]">
        <AdminSidebar userName={session.user.name} links={visibleLinks} />

        <main className="min-w-0 bg-neutral-100 text-black">
          <div className="border-b border-black/10 bg-white px-6 py-4">
            <div className="text-sm text-neutral-500">Signed in as</div>
            <div className="font-medium">{session.user.email}</div>
          </div>

          <div className="p-6">{children}</div>
        </main>
      </div>
    </div>
  );
}