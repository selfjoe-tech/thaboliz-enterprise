import { listEmployees } from "@/app/lib/actions/dashboard-info/employees";

type SearchParams = Promise<{
  search?: string;
}>;

export default async function EmployeesPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const sp = await searchParams;
  const search = typeof sp?.search === "string" ? sp.search : "";

  const { members, invites } = await listEmployees(search);

  return (
    <main className="p-4 md:p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Employees</h1>
        <p className="mt-1 text-sm text-gray-600">
          People who currently have access to this company account.
        </p>
      </div>

      <form className="mb-6">
        <input
          type="text"
          name="search"
          defaultValue={search}
          placeholder="Search by name, email, or role..."
          className="w-full max-w-md rounded-lg border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black"
        />
      </form>

      <section className="mb-8 overflow-x-auto rounded-xl border border-gray-200 bg-white">
        <div className="border-b border-gray-200 px-4 py-3">
          <h2 className="font-semibold">Active access</h2>
        </div>

        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Role</th>
              <th className="px-4 py-3">Access</th>
              <th className="px-4 py-3">Added</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-gray-200">
            {members.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-gray-500">
                  No employees found.
                </td>
              </tr>
            ) : (
              members.map((member: any) => (
                <tr key={member.id}>
                  <td className="px-4 py-3">{member.profile?.full_name || "Unnamed user"}</td>
                  <td className="px-4 py-3">{member.profile?.email || "-"}</td>
                  <td className="px-4 py-3 capitalize">{member.role}</td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs ${
                        member.is_active
                          ? "bg-green-100 text-green-700"
                          : "bg-gray-200 text-gray-600"
                      }`}
                    >
                      {member.is_active ? "Active" : "Disabled"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {new Date(member.created_at).toLocaleDateString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </section>

      <section className="overflow-x-auto rounded-xl border border-gray-200 bg-white">
        <div className="border-b border-gray-200 px-4 py-3">
          <h2 className="font-semibold">Pending invites</h2>
        </div>

        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Role</th>
              <th className="px-4 py-3">Sent</th>
              <th className="px-4 py-3">Expires</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-gray-200">
            {invites.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-4 py-8 text-center text-gray-500">
                  No pending invites.
                </td>
              </tr>
            ) : (
              invites.map((invite: any) => (
                <tr key={invite.id}>
                  <td className="px-4 py-3">{invite.email}</td>
                  <td className="px-4 py-3 capitalize">{invite.role}</td>
                  <td className="px-4 py-3">
                    {new Date(invite.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3">
                    {new Date(invite.expires_at).toLocaleDateString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </section>
    </main>
  );
}