import { requireTenantContext } from "@/app/lib/server/current-tenant";

export async function listEmployees(search = "") {
  const { supabase, tenantId } = await requireTenantContext();

  const [{ data: members, error: membersError }, { data: invites, error: invitesError }] =
    await Promise.all([
      supabase
        .from("tenant_memberships")
        .select(`
          id,
          role,
          is_active,
          created_at,
          profile:user_profiles!tenant_memberships_user_id_fkey (
            id,
            full_name,
            email,
            phone
          )
        `)
        .eq("tenant_id", tenantId)
        .order("created_at", { ascending: false }),

      supabase
        .from("tenant_invites")
        .select("id, email, role, created_at, expires_at, accepted_at")
        .eq("tenant_id", tenantId)
        .is("accepted_at", null)
        .order("created_at", { ascending: false }),
    ]);

  if (membersError) throw membersError;
  if (invitesError) throw invitesError;

  const q = search.trim().toLowerCase();

  const filteredMembers = (members ?? []).filter((member: any) => {
    const name = member.profile?.full_name?.toLowerCase() ?? "";
    const email = member.profile?.email?.toLowerCase() ?? "";
    return !q || name.includes(q) || email.includes(q) || member.role.includes(q);
  });

  const filteredInvites = (invites ?? []).filter((invite: any) => {
    const email = invite.email?.toLowerCase() ?? "";
    return !q || email.includes(q) || invite.role.includes(q);
  });

  return {
    members: filteredMembers,
    invites: filteredInvites,
  };
}