import { createClient } from "@/lib/supabase/server";

export async function requireTenantContext() {
  const supabase = await createClient();

  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    throw new Error("Not authenticated");
  }

  const { data: membership, error: membershipError } = await supabase
    .from("tenant_memberships")
    .select(`
      tenant_id,
      role,
      tenant:tenants!inner (
        id,
        name,
        slug
      )
    `)
    .eq("user_id", user.id)
    .eq("is_active", true)
    .order("created_at", { ascending: true })
    .limit(1)
    .single();

  if (membershipError || !membership) {
    throw new Error("No active tenant membership found");
  }

  return {
    supabase,
    user,
    tenantId: membership.tenant_id as string,
    role: membership.role as "owner" | "admin" | "manager" | "staff",
    tenant: membership.tenant as {
      id: string;
      name: string;
      slug: string;
    },
  };
}