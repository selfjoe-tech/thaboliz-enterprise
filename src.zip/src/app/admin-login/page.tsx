import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import ThabolizLogo from "@/components/brand/ThabolizLogo";
import LoginForm from "@/components/admin/login/LoginForm";
import { authOptions } from "@/lib/auth";

export const metadata = {
  title: "Admin Login | Thaboliz",
  description: "Secure access to the Thaboliz admin dashboard.",
};

export default async function AdminLoginPage({
  searchParams,
}: {
  searchParams?: any;
}) {
  const sp =
    searchParams && typeof searchParams.then === "function"
      ? await searchParams
      : searchParams ?? {};

  const callbackUrl =
    typeof sp?.callbackUrl === "string" && sp.callbackUrl.trim()
      ? sp.callbackUrl
      : "/admin/products";

  const session = await getServerSession(authOptions);

  if (session?.user?.isActive) {
    const permissions = session.user.permissions ?? [];
    if (permissions.includes("access_admin")) {
      redirect(callbackUrl);
    }
    redirect("/");
  }

  return (
    <main className="min-h-screen bg-neutral-950 text-white">
      <div className="grid min-h-screen lg:grid-cols-[1.05fr_0.95fr]">
        <section className="relative hidden overflow-hidden lg:flex">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(255,255,255,0.14),transparent_32%),radial-gradient(circle_at_bottom_right,rgba(14,165,233,0.18),transparent_28%)]" />
          <div className="absolute inset-0 bg-gradient-to-br from-neutral-950 via-black to-neutral-900" />

          <div className="relative z-10 flex h-full w-full flex-col justify-between p-10 xl:p-14">
            <div>
              <ThabolizLogo
                width={170}
                height={52}
                className="h-auto w-[170px]"
                priority
              />
            </div>

            <div className="max-w-xl">
              <p className="mb-4 text-sm uppercase tracking-[0.28em] text-white/45">
                Admin portal
              </p>
              <h1 className="max-w-[10ch] text-5xl font-semibold leading-[0.95] tracking-tight xl:text-6xl">
                Secure access for operations and catalogue management
              </h1>
              <p className="mt-6 max-w-lg text-base leading-7 text-white/68 xl:text-lg">
                Manage products, categories, publishing workflows, and internal
                operations from one controlled environment.
              </p>

              <div className="mt-10 grid gap-3 text-sm text-white/72 sm:grid-cols-2">
                <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
                  Product publishing
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
                  Category management
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
                  Order operations
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
                  Admin-only access
                </div>
              </div>
            </div>

            <div className="text-xs text-white/35">Thaboliz Admin</div>
          </div>
        </section>

        <section className="flex min-h-screen items-center justify-center bg-white px-5 py-10 text-black sm:px-8">
          <div className="w-full max-w-md">
            <div className="mb-8 lg:hidden">
              <ThabolizLogo
                width={150}
                height={46}
                className="h-auto w-[150px]"
                priority
              />
            </div>

            <div className="mb-8">
              <p className="text-sm uppercase tracking-[0.24em] text-neutral-500">
                Welcome back
              </p>
              <h2 className="mt-3 text-3xl font-semibold tracking-tight text-neutral-950">
                Sign in to the admin dashboard
              </h2>
              <p className="mt-3 text-sm leading-6 text-neutral-600">
                Enter your work email to continue. If this is your first login,
                you will be guided to create a password.
              </p>
            </div>

            <div className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-[0_20px_70px_-28px_rgba(0,0,0,0.28)] sm:p-8">
              <LoginForm />
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}