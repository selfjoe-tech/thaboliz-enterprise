// app/api/categories/create/route.ts
import { NextResponse } from "next/server";
import { supabase } from "@/app/lib/supabaseClient";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, status = "unpublished", description } = body;

    if (!name || !name.trim()) {
      return NextResponse.json({ success: false, error: "Name is required" }, { status: 400 });
    }

    const { data, error } = await supabase
      .from("catalogue_categories")
      .insert([{ name: name.trim(), description }])
      .select()
      .single();

    if (error) {
      console.error("create category error:", error);
      return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true, category: data });
  } catch (err) {
    console.error("create category route error:", err);
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}
