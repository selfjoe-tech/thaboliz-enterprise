import Link from "next/link";
import {
  Facebook,
  Instagram,
  Linkedin,
  Twitter,
  Youtube,
  ArrowUpRight,
  Mail,
  Phone,
  MapPin,
} from "lucide-react";

import ThabolizLogo from "../brand/ThabolizLogo";

import RouteLogo from "@/components/brand/RouteLogo";

function FooterHeading({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-3xl font-bold text-white">
      {children}
    </div>
  );
}

function FooterLink({
  href,
  children,
  className = "",
}: {
  href: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <Link
      href={href}
      className={[
        "group inline-flex items-center gap-2 text-sm text-white/70 hover:text-white transition",
        className,
      ].join(" ")}
    >
      <span className="truncate">{children}</span>
      <ArrowUpRight className="h-3.5 w-3.5 opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition" />
    </Link>
  );
}

function SocialIcon({
  href,
  label,
  children,
}: {
  href: string;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      aria-label={label}
      className={[
        "group inline-flex h-10 w-10 items-center justify-center rounded-none",
        "border border-white/10 bg-white/[0.03] text-white/70",
        "hover:bg-white/[0.06] hover:text-white transition",
      ].join(" ")}
    >
      {children}
    </Link>
  );
}

export default function SiteFooter() {
  const year = new Date().getFullYear();

  const divisions = [
    { label: "Construction", href: "/services/construction" },
    { label: "Technologies", href: "/services/technologies" },
    { label: "Ecommerce Products", href: "/services/enterprise/products" },
    // { label: "Mining", href: "/services/mining" },
    { label: "Logistics", href: "/services/logistics" },
    { label: "Integrated Farms", href: "/services/integrated-farms" },
    { label: "Enterprise", href: "/services/enterprise" },

    // { label: "Oil & gas", href: "/services/oil-and-gas" },
    // { label: "Green energy", href: "/services/green-energy" },
    // { label: "Research & innovation", href: "/services/research" },
    // { label: "Tenders", href: "/services/tenders" },
  ];

  const companyLinks = [
    { label: "About us", href: "/about" },
    // { label: "Services", href: "/services" },
    { label: "Contact", href: "/#contact" },
  ];

  return (
    <footer className="relative bg-black border-t border-white/10 overflow-hidden">
      {/* subtle background texture */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(900px_400px_at_15%_20%,rgba(255,255,255,0.06),transparent_60%),radial-gradient(700px_320px_at_85%_30%,rgba(255,0,80,0.08),transparent_55%)]" />

      <div className="relative mx-auto max-w-6xl px-4 py-14">
        {/* Top grid */}
        <div className="grid gap-10 md:grid-cols-12">
          {/* Brand / summary */}
          <div className="md:col-span-4">
            <Link href="/" className="inline-flex items-center gap-2">
                <RouteLogo width={160} height={32} />
            </Link>

            <p className="mt-4 text-md leading-relaxed text-white/65">
              We deliver across essential industries, combining on-the-ground execution
              with modern systems to build solutions that last.
            </p>

            
          </div>

          {/* Divisions */}
          <div className="md:col-span-5">
            <FooterHeading>Services</FooterHeading>

            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2">
              {divisions.map((d) => (
                <FooterLink key={d.href} href={d.href}>
                  {d.label}
                </FooterLink>
              ))}
            </div>
          </div>

          {/* Company / Contact */}
          <div className="md:col-span-3">
            <FooterHeading>Company</FooterHeading>
            <div className="mt-4 space-y-2">
              {companyLinks.map((l) => (
                <FooterLink key={l.href} href={l.href}>
                  {l.label}
                </FooterLink>
              ))}
            </div>

            <div className="mt-8">
              <FooterHeading>Contact</FooterHeading>
              <div className="mt-4 space-y-3 text-sm text-white/70">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-white/55" />
                  <span>info@thaboliz.co.za</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-white/55" />
                  <span>+27 73 811 1233</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-white/55" />
                  <span>South Africa</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="mt-12 border-t border-white/10" />

        {/* Bottom bar */}
        <div className="mt-6 flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
          <div className="text-xs text-white/55">
            © {year} Thaboliz. All rights reserved.
          </div>

          <p className="flex gap-1 text-nowrap text-white/55">
            Developed by 
            <Link
            href={"https://thaboliz.co.za/services/technologies"}
            className="text-blue-500 underline"
          >
            Thaboliz Technologies
          </Link>
          </p>

          


          
          <p className="flex gap-1 text-nowrap text-white/55">
            Images and illustrations by
            <Link
            href={"https://www.freepik.com/"}
            className="text-blue-500 underline"
          
          >
            Freepik

          </Link>
          </p>
          

          {/* <div className="flex flex-wrap items-center gap-4 text-xs text-white/60">
            <Link href="/privacy" className="hover:text-white transition">
              Privacy Policy
            </Link>
            <span className="text-white/20">•</span>
            <Link href="/terms" className="hover:text-white transition">
              Terms of service
            </Link>
            <span className="text-white/20">•</span>
            
          </div> */}

          {/* <div className="flex items-center gap-2">
            <SocialIcon href="#" label="Facebook">
              <Facebook className="h-4 w-4" />
            </SocialIcon>
            <SocialIcon href="#" label="Instagram">
              <Instagram className="h-4 w-4" />
            </SocialIcon>
            <SocialIcon href="#" label="X">
              <Twitter className="h-4 w-4" />
            </SocialIcon>
            <SocialIcon href="#" label="LinkedIn">
              <Linkedin className="h-4 w-4" />
            </SocialIcon>
            <SocialIcon href="#" label="YouTube">
              <Youtube className="h-4 w-4" />
            </SocialIcon>
          </div> */}
        </div>
      </div>
    </footer>
  );
}
